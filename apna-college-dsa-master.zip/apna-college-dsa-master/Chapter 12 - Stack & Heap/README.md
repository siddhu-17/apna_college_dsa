## Resources

1. [Stack vs Heap Memory Allocation](https://www.geeksforgeeks.org/stack-vs-heap-memory-allocation/)
2. [new and delete Operators](https://www.geeksforgeeks.org/new-and-delete-operators-in-cpp-for-dynamic-memory/)
3. [Apna College Video](https://www.youtube.com/watch?v=bbym08gSWvQ)
