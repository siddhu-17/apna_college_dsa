## Order of Problems

1. Rat in a maze    *`!medium`*
2. N-Queen problem    *`!medium`*
