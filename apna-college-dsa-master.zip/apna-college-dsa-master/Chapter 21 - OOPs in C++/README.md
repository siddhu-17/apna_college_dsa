## Topics to study

1. Classes & objects
2. Access modifiers - public, private and protected
6. Getter and setter functions
3. Constructors - default, parametrized & copy
4. Deep & shallow copy (copy constructors)
5. Destructors
7. Inheritance & its types
8. Polymorphism - function overloading, function overriding, operator overloading
9. Virtual functions, static and dynamic binding
