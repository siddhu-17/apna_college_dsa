## Order of Problems

1. Introduction & heapify    *`!fundamental`*
2. HeapSort    *`!fundamental`*
3. Heaps STL (Priority Queue)
4. Median of running stream    *`!medium`*
5. Merge k sorted arrays    *`!hard`*
6. Smallest sequence with sum K
