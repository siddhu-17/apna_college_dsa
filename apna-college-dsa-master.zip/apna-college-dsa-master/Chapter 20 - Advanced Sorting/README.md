## Order of Problems

1. Count sort
2. DNF (Dutch National Flag) sort
3. Wave sort    *`!improtant`*
