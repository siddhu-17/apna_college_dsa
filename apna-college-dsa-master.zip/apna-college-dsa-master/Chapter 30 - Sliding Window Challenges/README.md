## Order of Problems

1. Max sum subarray of size = K and sum < X
2. Smallest subarray with sum > X
3. Number formed by subarray of size k which is divisible by 3
4. Subarray with palindromic concatenation
5. Perfect numbers in subarrays    *`!good problem`*
