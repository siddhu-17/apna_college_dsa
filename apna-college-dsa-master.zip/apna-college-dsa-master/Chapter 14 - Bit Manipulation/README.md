## Order of Problems

1. Basics of bit manipulation
2. Check if a number is power of 2
3. Count the number of 1's
4. Generate all possible subsets    *`!logic`*

### Challenges from [Video](https://www.youtube.com/watch?v=WEpLyOc0bCE)

5. Find unique number in an array
6. Find two unique numbers in an array    *`!logic`*
7. Find unique number from an array of elements repeating thrice    *`!logic`*
