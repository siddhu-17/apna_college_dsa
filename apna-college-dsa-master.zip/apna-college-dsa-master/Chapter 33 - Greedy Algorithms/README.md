## Order of Problems

1. Indian coin change
2. Activity selection problem    *`!medium`*
3. Fractional knapsack
4. Optimal merge patterns
5. Expedi (expedition) - SPOJ    *`!extremely hard`*
6. Maximum & minimum array difference
