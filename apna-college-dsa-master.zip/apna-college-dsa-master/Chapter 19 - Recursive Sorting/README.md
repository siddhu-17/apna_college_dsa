## Order of Problems

1. Reduce the array    *`!concept, vectors & pair`*
2. Merge sort
3. Quick sort
4. Count inversions    *`!logic`*
