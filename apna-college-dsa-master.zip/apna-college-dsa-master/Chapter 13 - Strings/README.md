## Order of Problems

1. String into uppercase & lowercase
2. Form the biggest number from a numeric string
3. Output character with highest frequency
