## Order of Problems

1. Introduction
2. Searching a matrix
3. Spiral order matrix traversal
4. Matrix transpose
5. Matrix multiplication   *`!logic`*
6. Matrix binary search   *`!logic`*
