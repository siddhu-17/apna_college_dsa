## Order of Problems

1. Introduction to stacks
2. Stack implementation using linked lists
3. Reverse a sentence using stack
4. Reverse a stack    *`!concept`*
5. Prefix evaluation
6. Postfix evaluation
7. Infix to postfix
8. Infix to prefix
9. Balanced paranthesis
