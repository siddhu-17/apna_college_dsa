## Order of Problems

1. Print primes between two numbers
2. Print Fibonacci series
3. Calculate factorial of a number
4. Calculate binary coefficient(nCr)
5. Pascal's riangle *(pending)*
6. Check for pythagorian triplet

### Number system conversions (important)

7. Binary to decimal
8. Octal to decimal
9. Hexadecimal to decimal

*(pending)*

10. Decimal to binary
11. Decimal to octal
12. Decimal to hexadecimal
13. Add two binary numbers