## Resources

1. [C++ Pointers](https://www.geeksforgeeks.org/cpp-pointers/)
2. [Pointers & Arrays](https://www.geeksforgeeks.org/pointer-array-array-pointer/)
3. [Apna College Video](https://www.youtube.com/watch?v=gHxmAgedyDk)
