# DSA Programs from Apna College

This repository contains all the programs that are taught in Apna College's DSA ith C++ playlist. I'll try to commit to this repository daily until entire playlist and all the concepts are covered.

Topics in this repo are categorized as chapter's as the instructors do it. Each chapter folder has a seperate README file which contains the order of problems and other important information about them.
## Run Locally

Clone the project. Open any folder, whose file you want to execute and run the following command:

```bash
  g++ {filename}.cpp -o {filename}
  ./{filename}
```

Now give the input to the program to check your test cases.

__*Or, you can simply use the Code Runner & Competitive Programming Helper (CPH) extensions*__ ✨