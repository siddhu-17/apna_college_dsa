## Order of Problems

1. Check for prime number
2. Reverse a number
3. Check if a number is an Armstrong number