## Order of Problems

1. Introduction to linked lists
2. Reverse a linked list
3. Reverse k nodes in a linked list    *`!hard`*
4. Detect & remove cycle in a list    *`!important concept`*
5. Doubly linked list
6. Append last k nodes of a list to begining    *`!medium`*
7. Find intersection point of two lists    *`!medium`*
8. Merge two sortd lists
9. Circular linked list
10. Put odd position nodes after even position nodes
