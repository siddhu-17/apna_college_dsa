## Order of Problems

1. Check palindrome
2. Largest word in a sentence   *`!logic`*
