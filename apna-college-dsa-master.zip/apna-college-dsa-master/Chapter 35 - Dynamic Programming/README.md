## Order of Problems

1. Introduction
2. Nth fibonacci number
3. Minimum number of squares whose sum equals to given number n    *`!concept`*
4. Coin change problem    *`!medium`*
5. Kadane's algorithm
6. 01 Knapsack
7. Longest increasing subsequence
