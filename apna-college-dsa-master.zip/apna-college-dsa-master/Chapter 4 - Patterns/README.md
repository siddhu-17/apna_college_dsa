## Problem Order

1. Rectangle pattern
2. Hollow rectangle pattern
3. Inverted half pyramid
4. 180 degree rotated half pyramid
5. Half pyramid using numbers
6. Floyd's triangle
7. Butterfly pattern
8. Inverted number pattern
9. 0-1 pattern
10. Rhombus pattern
11. Number triangle
12. Palindromic pattern
13. Star pattern
14. Zig-zag pattern

`A good approach in patterns is to start counting from 1`