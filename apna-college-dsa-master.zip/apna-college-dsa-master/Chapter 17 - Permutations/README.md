## Order of Problems

1. Return all possible permutations of an array having no duplicate numbers
2. Return all possible permutations of an array having duplicate numbers
