## Order of Problems

1. Sieve of Eratosthenes    *`!logic`*
2. Prime factorisation using sieve
3. Inclusion - exclusion priciple (find number of integers divisible by two numbers upto a given number)
4. Euclid algorithm to find GCD    *`!logic`*
